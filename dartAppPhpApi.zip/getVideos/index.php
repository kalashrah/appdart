<?php

// header('Content-Type: text/plan; charset=UTF-8');

header("Content-Type: application/json");

// header("Content-Type: application/json charset=UTF-8");
// error_reporting(0);
// ini_set('display_errors', 0);

$curl = curl_init();

curl_setopt_array($curl, array(
  CURLOPT_URL => 'https://ikalashrah.000webhostapp.com/dartApp/getVideos/videos.json',
  CURLOPT_RETURNTRANSFER => true,
  CURLOPT_ENCODING => '',
  CURLOPT_MAXREDIRS => 10,
  CURLOPT_TIMEOUT => 0,
  CURLOPT_FOLLOWLOCATION => true,
  CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
  CURLOPT_CUSTOMREQUEST => 'GET',
  CURLOPT_HTTPHEADER => array(
    ': '
  ),
));

// id.children[0].children[0].children[0].href
// id.children[0].children[0].children[0].children[0].src
// id.children[0].children[0].children[1].children[0].textContent
// for(i = 0; i <id.children.length; i++){
//   link = id.children[i].children[0].children[0].href;
// img = id.children[i].children[0].children[0].children[0].src;
// descrioption = id.children[i].children[0].children[1].children[0].textContent;
// newVP = {
//   'videoLink': link,
//   'imgLink': img,
//   'descrioption': descrioption
// };
// videoPosts.push(newVP);
// }

$response = curl_exec($curl);

curl_close($curl);
echo $response;
