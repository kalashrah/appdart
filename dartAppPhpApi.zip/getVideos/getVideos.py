from pydoc import classname
from random import random
from urllib.request import urlopen
from bs4 import BeautifulSoup as bs
import requests
import json
import re
# import numpy as nb

url = 'https://www.spl.sa/ar/videos-list'
ull = requests.get('https://www.spl.sa/ar/videos-list')
client = urlopen(url)

html = client.read()

# soup = bs(html, 'lxml')

# soup = bs(html, 'lxml')
# soup = bs(ull.c , 'lxml')
soup = bs(ull.content, 'html.parser')

# filterlinks = soup.find(attrs={'class' : 'col-12 col-md-4'})
# filterId = soup.find_all(id='playlist');
# filterId = soup.find_all('div', {'class': 'col-12'});

# link = 'https://www.spl.sa' + getlinks[0].h6.find_all('a')[1]['href']
ch = soup.findAll("div", class_="col-md-4")
# print(filterlinks)

# client.close()
# link = 'https://www.spl.sa'+skill.h6.find_all('a')[1]['href']
#         description = skill.h6.find_all('a')[1].text
#         imgsrc = "https://www.spl.sa"+skill.img["src"]
# filterlinks = filterId.findAll(attrs={'class' : 'col-12'})
# getlinks = filterId.find_all('div', {'class':'col-12'})
# a = getlinks[0].a
# getlinks = soup.find_all('div', class_='card')

# getlinks = filterlinks.find_all('div', class_='posts__item')
print(type(ch))
print(len(ch))
# print(getlinks)
# fullLink = 'https://www.spl.sa' + getlinks[0].img['src']
# print(fullLink)

newsPosts = []





# for skill in getlinks:

#         Link = str(skill.img['src'])
#         fullLink = 'https://www.spl.sa' + Link

#         post = {
#             "link": fullLink
#         }
#         newsPosts.append(post)

# print(newsPosts)

# val = str(newsPosts)

# f = open('Photos.json', 'w')
# f.write(val)
# f.close()