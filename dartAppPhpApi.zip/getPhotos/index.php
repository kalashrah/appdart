<?php

// header('Content-Type: text/plan; charset=UTF-8');

header("Content-Type: application/json");

// header("Content-Type: application/json charset=UTF-8");
// error_reporting(0);
// ini_set('display_errors', 0);

$curl = curl_init();

curl_setopt_array($curl, array(
  CURLOPT_URL => 'https://ikalashrah.000webhostapp.com/dartApp/getPhotos/Photos.json',
  CURLOPT_RETURNTRANSFER => true,
  CURLOPT_ENCODING => '',
  CURLOPT_MAXREDIRS => 10,
  CURLOPT_TIMEOUT => 0,
  CURLOPT_FOLLOWLOCATION => true,
  CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
  CURLOPT_CUSTOMREQUEST => 'GET',
  CURLOPT_HTTPHEADER => array(
    ': '
  ),
));

$response = curl_exec($curl);

curl_close($curl);
echo $response;
