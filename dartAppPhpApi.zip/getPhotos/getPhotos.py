from pydoc import classname
from random import random
from urllib.request import urlopen
from bs4 import BeautifulSoup as bs
import requests
import json
# import numpy as nb

url = 'https://www.spl.sa/ar/gallery'

client = urlopen(url)

html = client.read()

# soup = bs(html, 'lxml')

soup = bs(html, 'lxml')
# soup = bs(html, 'html.parser')

filterlinks = soup.find(attrs={'class' : 'gallery__thumb'})

# print(filterlinks)

# client.close()

getlinks = soup.find_all('figure', class_='gallery__thumb')

# getlinks = filterlinks.find_all('div', class_='posts__item')

# print(len(getlinks))
# fullLink = 'https://www.spl.sa' + getlinks[0].img['src']
# print(fullLink)

newsPosts = []





for skill in getlinks:

        Link = str(skill.img['src'])
        fullLink = 'https://www.spl.sa' + Link

        post = {
            "link": fullLink
        }
        newsPosts.append(post)

print(newsPosts)

val = str(newsPosts)

f = open('Photos.json', 'w')
f.write(val)
f.close()